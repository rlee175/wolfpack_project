from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.controllers import users_controller
from flask_bcrypt import Bcrypt
from flask import flash
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
lowPW_REGEX = re.compile(r"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$")
LETTERS_REGEX = re.compile(r'^([a-zA-Z])+$')

bcrypt = Bcrypt(app)

class User:
    DB ='cars'

    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @staticmethod
    def validate_user(user):
        valid = True
        query = "SELECT * FROM users WHERE email = %(email)s;"
        results = connectToMySQL(User.DB).query_db(query, user)
        if len(user['first_name'])<1 or len(user['last_name'])<1 or len(user['email'])<1 or len(user['password'])<1:
            flash("Fields cannot be left blank.", 'register')
            valid = False
        if len(results) >= 1:
            flash("Email is already registered", 'register')
            valid = False
        if not LETTERS_REGEX.match(user['first_name']):
            flash("Only letters are allowed for FIRST name",'register')
            valid = False
        if not LETTERS_REGEX.match(user['last_name']):
            flash("Only letters are allowed for LAST name",'register')
            valid = False
        if len(user['first_name'])<=2:
            flash("FIRST name must be atleast 3 characters",'register')
            valid = False
        if len(user['last_name'])<=2:
            flash("LAST name must be atleast 3 characters",'register')
            valid = False
        if not EMAIL_REGEX.match(user['email']):
            flash("invalid Email", 'register')
            valid = False
        if not lowPW_REGEX.match(user['password']):
            flash ("Invalid Password: Must follow the password criteria in the form", 'register')
            valid = False
        if not user['password'] == user['confirm']:
            flash('Passwords Do Not Match', 'register')
            valid = False
        return valid
    

    @classmethod
    def save(cls, data):
        query ="""INSERT INTO users (first_name, last_name, email, password)
                    VALUES (%(first_name)s, %(last_name)s, %(email)s, %(password)s); 
                """
        return connectToMySQL(cls.DB).query_db(query, data)
    
    @classmethod
    def get_one_by_email(cls, data):
        query = """SELECT * FROM users
                WHERE email = %(email)s;
            """
        result = connectToMySQL(cls.DB).query_db(query, data)

        if len(result) <1:
            return False
        return cls(result[0])
    
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        results = connectToMySQL(cls.db).query_db(query)
        users = []
        for row in results:
            users.append( cls(row))
        return users
    
    @classmethod
    def get_by_id(cls, data):
        query = """SELECT * FROM users
                WHERE id = %(user_id)s;
            """
        result = connectToMySQL(cls.DB).query_db(query, data)
        return cls(result[0])