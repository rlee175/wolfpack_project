from flask_app import app
from flask import render_template, redirect, session, request, flash
from flask_bcrypt import Bcrypt
from flask_app.models.user_model import User



bcrypt = Bcrypt(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=["POST"])
def register():
    if not User.validate_user(request.form):
        return redirect('/')
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    print(pw_hash)
    data = {
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email'],
        'password': pw_hash
    }
    user_id = User.save(data)
    session['user_id'] = user_id
    return redirect('/dashboard')

@app.route('/login', methods=["POST"])
def login():
    data = {
        'email': request.form['email']
        
    }
    user_in_db = User.get_one_by_email(data)

    if request.form['email'] =='' or request.form['password'] == '':
        flash('Fields cannot be left blank', 'login')
        return redirect('/')
    if not user_in_db:
        flash('Invalid EMAIL/password', 'login') #I am using to all caps for EMAIL for testing environment to see that validation is occurring for the correct input
        return redirect('/')
    if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
        flash('Invalid email/PASSWORD', 'login')
        return redirect('/')

    session['user_id']= user_in_db.id
    return redirect('/dashboard')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        'user_id': session['user_id']
    }

    return render_template ('dashboard.html', user = User.get_by_id(data)) 
    #ADD with new Class: , everything = WHATEVER.get_everything()

@app.route('/logout')
def logout():
    session.clear()
    return redirect ('/')