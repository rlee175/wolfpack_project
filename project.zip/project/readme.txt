Project to build a website where Endurance athletes can learn about 
safely and properly training for endurance events (specifically catered towrds triathletes)

